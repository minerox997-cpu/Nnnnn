package com.emberwraith;

import net.minecraftforge.fml.common.Mod;

@Mod(modid = EmberWraithMod.MODID, name = "Ember Wraith", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class EmberWraithMod {
    public static final String MODID = "emberwraith";
}
