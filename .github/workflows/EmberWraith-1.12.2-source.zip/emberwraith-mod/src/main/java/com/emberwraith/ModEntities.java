package com.emberwraith;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

@Mod.EventBusSubscriber(modid = EmberWraithMod.MODID)
public class ModEntities {

    @SubscribeEvent
    public static void registerEntities(RegistryEvent.Register<EntityEntry> event) {
        List<Biome> biomes = new ArrayList<Biome>();
        for (Biome b : ForgeRegistries.BIOMES.getValuesCollection()) {
            if (BiomeDictionary.hasType(b, BiomeDictionary.Type.NETHER)
                    || BiomeDictionary.hasType(b, BiomeDictionary.Type.MESA)
                    || BiomeDictionary.hasType(b, BiomeDictionary.Type.SANDY)) {
                biomes.add(b);
            }
        }

        event.getRegistry().register(
            EntityEntryBuilder.create()
                .entity(EntityEmberWraith.class)
                .id(new ResourceLocation(EmberWraithMod.MODID, "ember_wraith"), 0)
                .name("ember_wraith")
                .tracker(64, 3, true)
                .egg(0x2A0A00, 0xFFB300)
                .spawn(EnumCreatureType.MONSTER, 14, 1, 2, biomes.toArray(new Biome[0]))
                .build()
        );
    }
}
