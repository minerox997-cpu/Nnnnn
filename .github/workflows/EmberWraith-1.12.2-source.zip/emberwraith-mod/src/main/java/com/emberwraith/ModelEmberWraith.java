package com.emberwraith;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ModelEmberWraith extends ModelBase {
    private final ModelRenderer head, hornL, hornR, body, tail, tail2, armR, armL;
    private final ModelRenderer[] embers = new ModelRenderer[5];

    public ModelEmberWraith() {
        this.textureWidth = 64;
        this.textureHeight = 64;

        head = new ModelRenderer(this, 0, 0);
        head.addBox(-4F, -8F, -4F, 8, 8, 8);
        head.setRotationPoint(0F, 0F, 0F);

        hornL = new ModelRenderer(this, 32, 0);
        hornL.addBox(-1F, -5F, -1F, 2, 5, 2);
        hornL.setRotationPoint(3F, -7F, 0F);
        hornL.rotateAngleZ = 0.35F;
        head.addChild(hornL);

        hornR = new ModelRenderer(this, 32, 0);
        hornR.addBox(-1F, -5F, -1F, 2, 5, 2);
        hornR.setRotationPoint(-3F, -7F, 0F);
        hornR.rotateAngleZ = -0.35F;
        head.addChild(hornR);

        body = new ModelRenderer(this, 0, 16);
        body.addBox(-4F, 0F, -2F, 8, 10, 4);
        body.setRotationPoint(0F, 0F, 0F);

        tail = new ModelRenderer(this, 24, 16);
        tail.addBox(-3F, 0F, -1.5F, 6, 8, 3);
        tail.setRotationPoint(0F, 10F, 0F);

        tail2 = new ModelRenderer(this, 24, 28);
        tail2.addBox(-2F, 0F, -1F, 4, 6, 2);
        tail2.setRotationPoint(0F, 8F, 0F);
        tail.addChild(tail2);

        armR = new ModelRenderer(this, 40, 16);
        armR.addBox(-3F, -2F, -2F, 4, 10, 4);
        armR.setRotationPoint(-5F, 2F, 0F);

        armL = new ModelRenderer(this, 40, 16);
        armL.addBox(-1F, -2F, -2F, 4, 10, 4);
        armL.setRotationPoint(5F, 2F, 0F);

        for (int i = 0; i < embers.length; i++) {
            embers[i] = new ModelRenderer(this, 0, 40);
            embers[i].addBox(-1.5F, -1.5F, -1.5F, 3, 3, 3);
        }
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                       float netHeadYaw, float headPitch, float scale) {
        this.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);

        float bob = MathHelper.sin(ageInTicks * 0.1F) * 1.5F - 2.0F;
        GlStateManager.pushMatrix();
        GlStateManager.translate(0.0F, bob * scale, 0.0F);
        head.render(scale);
        body.render(scale);
        tail.render(scale);
        armR.render(scale);
        armL.render(scale);
        for (ModelRenderer e : embers) e.render(scale);
        GlStateManager.popMatrix();
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entity) {
        head.rotateAngleY = netHeadYaw * 0.017453292F;
        head.rotateAngleX = headPitch * 0.017453292F;

        float sway = MathHelper.cos(ageInTicks * 0.1F) * 0.08F;
        armR.rotateAngleZ = 0.25F + sway;
        armL.rotateAngleZ = -0.25F - sway;
        armR.rotateAngleX = -0.5F + MathHelper.sin(ageInTicks * 0.1F) * 0.1F;
        armL.rotateAngleX = -0.5F - MathHelper.sin(ageInTicks * 0.1F) * 0.1F;

        tail.rotateAngleX = 0.15F + MathHelper.sin(ageInTicks * 0.12F) * 0.1F;
        tail2.rotateAngleX = MathHelper.sin(ageInTicks * 0.12F + 1.0F) * 0.25F;

        // kule zaru orbituja wokol ducha
        for (int i = 0; i < embers.length; i++) {
            float a = ageInTicks * 0.09F + i * (float) (Math.PI * 2.0D / embers.length);
            embers[i].rotationPointX = MathHelper.cos(a) * 11.0F;
            embers[i].rotationPointZ = MathHelper.sin(a) * 11.0F;
            embers[i].rotationPointY = 8.0F + MathHelper.sin(ageInTicks * 0.13F + i * 1.3F) * 3.0F;
            embers[i].rotateAngleY = a;
        }
    }
}
