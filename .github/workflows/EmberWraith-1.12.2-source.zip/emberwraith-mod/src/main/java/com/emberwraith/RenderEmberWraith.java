package com.emberwraith;

import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderEmberWraith extends RenderLiving<EntityEmberWraith> {
    private static final ResourceLocation TEXTURE =
        new ResourceLocation(EmberWraithMod.MODID, "textures/entity/ember_wraith.png");

    public RenderEmberWraith(RenderManager manager) {
        super(manager, new ModelEmberWraith(), 0.4F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityEmberWraith entity) {
        return TEXTURE;
    }
}
