package com.emberwraith;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class EntityEmberWraith extends EntityMob {

    public EntityEmberWraith(World world) {
        super(world);
        this.setSize(0.7F, 2.0F);
        this.isImmuneToFire = true;
        this.experienceValue = 15;
    }

    @Override
    protected void initEntityAI() {
        this.tasks.addTask(4, new AIFireballAttack(this));
        this.tasks.addTask(5, new EntityAIMoveTowardsRestriction(this, 1.0D));
        this.tasks.addTask(7, new EntityAIWanderAvoidWater(this, 1.0D));
        this.tasks.addTask(8, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(8, new EntityAILookIdle(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, true));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(30.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.27D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(40.0D);
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(4.0D);
    }

    @Override
    public void fall(float distance, float damageMultiplier) {
        // lekki jak duch - brak obrazen od upadku
    }

    @Override
    public void onLivingUpdate() {
        // unoszenie sie: spadanie jest spowolnione
        if (!this.onGround && this.motionY < 0.0D) {
            this.motionY *= 0.6D;
        }

        if (this.world.isRemote) {
            for (int i = 0; i < 2; i++) {
                this.world.spawnParticle(EnumParticleTypes.FLAME,
                    this.posX + (this.rand.nextDouble() - 0.5D) * this.width,
                    this.posY + this.rand.nextDouble() * this.height,
                    this.posZ + (this.rand.nextDouble() - 0.5D) * this.width,
                    0.0D, 0.02D, 0.0D);
            }
            if (this.rand.nextInt(4) == 0) {
                this.world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL,
                    this.posX + (this.rand.nextDouble() - 0.5D) * this.width,
                    this.posY + this.height,
                    this.posZ + (this.rand.nextDouble() - 0.5D) * this.width,
                    0.0D, 0.05D, 0.0D);
            }
        }

        // woda ja rani
        if (this.isWet()) {
            this.attackEntityFrom(DamageSource.DROWN, 1.0F);
        }
        super.onLivingUpdate();
    }

    @Override
    public boolean attackEntityAsMob(Entity target) {
        boolean hit = super.attackEntityAsMob(target);
        if (hit) {
            target.setFire(6);
        }
        return hit;
    }

    @Override
    public void onDeath(DamageSource cause) {
        super.onDeath(cause);
        if (!this.world.isRemote && this.world.getGameRules().getBoolean("mobGriefing")) {
            // wybuch ognia wokol
            for (int i = 0; i < 6; i++) {
                BlockPos pos = new BlockPos(
                    this.posX + this.rand.nextInt(5) - 2,
                    this.posY,
                    this.posZ + this.rand.nextInt(5) - 2);
                if (this.world.isAirBlock(pos) && Blocks.FIRE.canPlaceBlockAt(this.world, pos)) {
                    this.world.setBlockState(pos, Blocks.FIRE.getDefaultState());
                }
            }
        }
        this.playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 0.6F, 1.5F);
    }

    @Override
    protected void dropFewItems(boolean wasRecentlyHit, int lootingModifier) {
        int powder = this.rand.nextInt(3 + lootingModifier);
        if (powder > 0) this.dropItem(Items.BLAZE_POWDER, powder);
        if (this.rand.nextInt(3) == 0) this.dropItem(Items.COAL, 1 + this.rand.nextInt(2));
        if (this.rand.nextInt(10) == 0) this.dropItem(Items.BLAZE_ROD, 1);
        if (wasRecentlyHit && this.rand.nextInt(25) == 0) this.dropItem(Items.NETHER_STAR, 1);
    }

    @Override
    public int getBrightnessForRender() {
        return 15728880;
    }

    @Override
    public float getBrightness() {
        return 1.0F;
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_BLAZE_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource src) { return SoundEvents.ENTITY_BLAZE_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_BLAZE_DEATH; }

    /** Atak: serie malych kul ognia, a z bliska - cios z podpaleniem. */
    static class AIFireballAttack extends EntityAIBase {
        private final EntityEmberWraith wraith;
        private int attackStep;
        private int attackTime;

        AIFireballAttack(EntityEmberWraith wraith) {
            this.wraith = wraith;
            this.setMutexBits(3);
        }

        @Override
        public boolean shouldExecute() {
            EntityLivingBase t = this.wraith.getAttackTarget();
            return t != null && t.isEntityAlive();
        }

        @Override
        public void startExecuting() {
            this.attackStep = 0;
        }

        @Override
        public void updateTask() {
            --this.attackTime;
            EntityLivingBase target = this.wraith.getAttackTarget();
            if (target == null) return;
            double distSq = this.wraith.getDistanceSq(target);

            if (distSq < 4.0D) {
                if (this.attackTime <= 0) {
                    this.attackTime = 20;
                    this.wraith.attackEntityAsMob(target);
                }
                this.wraith.getMoveHelper().setMoveTo(target.posX, target.posY, target.posZ, 1.0D);
            } else if (distSq < 256.0D) {
                double dx = target.posX - this.wraith.posX;
                double dy = target.getEntityBoundingBox().minY + target.height / 2.0F
                        - (this.wraith.posY + this.wraith.height / 2.0F);
                double dz = target.posZ - this.wraith.posZ;

                if (this.attackTime <= 0) {
                    ++this.attackStep;
                    if (this.attackStep == 1) {
                        this.attackTime = 50;
                    } else if (this.attackStep <= 4) {
                        this.attackTime = 6;
                    } else {
                        this.attackTime = 90;
                        this.attackStep = 0;
                    }

                    if (this.attackStep > 1) {
                        float f = MathHelper.sqrt(MathHelper.sqrt(distSq)) * 0.5F;
                        this.wraith.world.playEvent(null, 1018,
                            new BlockPos((int) this.wraith.posX, (int) this.wraith.posY, (int) this.wraith.posZ), 0);
                        EntitySmallFireball fb = new EntitySmallFireball(this.wraith.world, this.wraith,
                            dx + this.wraith.getRNG().nextGaussian() * f, dy,
                            dz + this.wraith.getRNG().nextGaussian() * f);
                        fb.posY = this.wraith.posY + this.wraith.height / 2.0F + 0.5D;
                        this.wraith.world.spawnEntity(fb);
                    }
                }
                this.wraith.getLookHelper().setLookPositionWithEntity(target, 10.0F, 10.0F);
            } else {
                this.wraith.getNavigator().clearPath();
                this.wraith.getMoveHelper().setMoveTo(target.posX, target.posY, target.posZ, 1.0D);
            }
            super.updateTask();
        }
    }
}
