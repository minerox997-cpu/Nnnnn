EMBER WRAITH - mod do Minecraft Java 1.12.2 (Forge)
====================================================
Nowy mob: Ember Wraith (Zarzacy Duch)
 - plonie, unosi sie, wokol krazy 5 kul zaru
 - strzela seriami kul ognia, z bliska podpala
 - odporny na ogien, rani go woda
 - po smierci rozpala ogien wokol (jesli mobGriefing = true)
 - drop: proszek z blaze'a, wegiel, rzadko pret blaze'a i gwiazda netheru
 - spawnuje sie na pustyniach, w mesie i w Netherze
 - ma jajko spawnujace (zakladka Misc) i komenda: /summon emberwraith:ember_wraith

JAK ZBUDOWAC .JAR (Windows/Mac/Linux, potrzebny JDK 8):
 1. Pobierz Forge MDK 1.12.2 (14.23.5.2860) ze strony files.minecraftforge.net
 2. Rozpakuj MDK do nowego folderu.
 3. Usun z niego folder src i plik build.gradle.
 4. Wrzuc tu moj folder src oraz moj build.gradle.
 5. W terminalu w tym folderze:   gradlew setupDecompWorkspace
                                  gradlew build
 6. Gotowy plik jest w build/libs/EmberWraith-1.12.2-1.0.jar
    -> wrzuc go do folderu mods w Minecraft 1.12.2 z Forge 14.23.5.2860.
